import sys
import pygame
import random
import ast


pygame.init()
pygame.mixer.init()

width = 400
height = 500
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Zniszcz Bloczki  ;)")

# Kolory
black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
pink = (255, 172, 203)
green = (0, 200, 50)
gold = (240, 165, 55)
blue = (10, 220, 255)
button_color = (150, 0, 100)
button_color_2 = (70, 0, 50)

game_font = pygame.font.SysFont("Consolas", 20)
background = pygame.image.load("Background.png")
background_2 = pygame.image.load("grafika.jpg")
clock = pygame.time.Clock()


pygame.mixer.music.load("OutThere.ogg")
collision_sound = pygame.mixer.Sound("collision.ogg")


with open('scores.txt', 'r') as f:
    lista_file = f.read()
listOfScores = ast.literal_eval(lista_file)

class Ball:
    def __init__(self, x, y, radius, speed, color):
        self.x, self.y = x, y
        self.radius = radius
        self.speed = speed
        self.color = color
        self.Δx, self.Δy = 1, 1
        self.bow = 0
  
        self.ball = pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)
  
    def display(self):
        self.ball = pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)

    def stop(self):
        self.Δx, self.Δy = 0, 0
        self.x ,self.y = 50, height-60
  
    def move(self):
        self.x += self.Δx*self.speed
        self.y += self.Δy*self.speed

        if self.y >= height:
            return True
        
        elif self.y <= 0:
            self.Δy *= -1
        
        elif self.x <= 0 or self.x >= width:
            self.Δx *= -1
 
        return False

    def reset(self):
        self.x = 0
        self.y = height-60
        self.Δx, self.Δy = 1, -1
        self.color = white
 
    def hit(self):
        # #wysokości na któruch jest możliwa kolizja boczna z bloczkami (rozpoczynamy tworzenie 
        # # bloczków od height=50 jeden bloczek ma wysokość równą 15 i między nimi są przerwy 
        # # o długości 20 i powstaje 7 rzędów bloczków. Rozpatrujemy również odbicie od wieżchołka 
        # # wg zasady czy jest ono bardziej z boku czy z góru stąd wachania o 2.5 ponieważ to r/2)
        # if (47.5< self.y <67.5 or 82.5< self.y <102.5 or 117.5< self.y <137.5 or 152.5< self.y <172.5 or 187.5< self.y <207.5 or 222.5< self.y <242.5 or 257.5< self.y <277.5) and 5.5 < self.x < width- 5.5:
        #     self.Δx *= -1
        # #odbicia bokiem (obszar pomiędzy)
        # elif height-55 < self.y < height-35 and 5.5 < self.x < width-5.5:
        #     self.Δx *= -1
        # #odbicia dołem platformy (lokalizacja platformy: height-55 + primień kuli: 5 + wysokość platformy: 10)
        # elif height-35 <= self.y:
        #     self.Δy = abs(self.Δy)
        # elif ( -5.5 <= self.x < 5.5 or width - 5.5 < self.x <= width + 5.5 ) and ( -5.5 < self.y < 5.5):
        #     self.Δy *= -1
        #     self.Δx *= -1
        # else:
        #     #odbicia górą platformy (lokalizacja platformy: height-55 - primień kuli: 5)
        #     self.Δy *= -1



        # print(self.x, self.y, self.Δx, self.Δy)
        # if 0 < self.x < width:
        #     if 48.5 <= self.y <= 66.5 or 83.5 <= self.y <= 101.5 or 118.5 <= self.y <= 136.5 or 153.5 <= self.y <= 171.5 or 188.5 <= self.y <= 206.5 or 223.5 <= self.y <= 241.5 or 258.5 <= self.y <= 276.5 or height - 51.5 <= self.y < height - 40:
        #         self.Δx *= -1
        #     elif 0 <= self.y <= 46.5 or 68.5 <= self.y <= 81.5 or 103.5 <= self.y <= 116.5 or 138.5 <= self.y <= 151.5 or 173.5 <= self.y <= 186.5 or 208.5 <= self.y <= 221.5 or 243.5 <= self.y <= 256.5 or 278.5 <= self.y <= height - 53.5:
        #         self.Δy *= -1
        #     elif 46.5 < self.y < 48.5 or 66.5 < self.y < 68.5 or 81.5 < self.y < 83.5 or 101.5 < self.y < 103.5 or 116.5 < self.y < 118.5 or 136.5 < self.y < 138.5 or 151.5 < self.y < 153.5 or 171.5 < self.y < 173.5 or 186.5 < self.y < 188.5 or 206.5 < self.y < 208.5 or 221.5 < self.y < 223.5 or 241.5 < self.y < 243.5 or 256.5 < self.y < 258.5 or 276.5 < self.y < 278.5 or height - 53.5 < self.y < height - 51.5:
        #         self.Δy *= -1
        #         self.Δx *= -1
        #     elif self.y >= height - 40:
        #         self.Δy = abs(self.Δy)
        # elif self.x == 0 or self.x == width:
        #     if self.y != 0:
        #         self.Δx *= -1
        #     elif self.y ==0:
        #         self.Δx *= -1
        #         self.Δy *= -1
        # print(self.Δx, self.Δy, "\n")


        if 0 < self.x < width:
            if 50 <= self.y <= 65 or 85 <= self.y <= 100 or 120 <= self.y <= 135 or 155 <= self.y <= 170 or 190 <= self.y <= 205 or 225 <= self.y <= 240 or 260 <= self.y <= 275 or height - 50 <= self.y < height - 40:
                self.Δx *= -1
            elif 0 <= self.y < 50 or 65 < self.y < 85 or 100 < self.y < 120 or 135 < self.y < 155 or 170 < self.y < 190 or 205 < self.y < 225 or 240 < self.y < 260 or 275 < self.y < height - 50:
                self.Δy *= -1
            elif self.y >= height - 40:
                self.Δy = abs(self.Δy)
        elif self.x == 0 or self.x == width:
            if self.y != 0:
                self.Δx *= -1
            elif self.y ==0:
                self.Δx *= -1
                self.Δy *= -1



        # RAINBOW_BALL    
        rain = [(255, 100, 100), (255, 120, 100), (255, 140, 100), (255, 160, 100), (255, 180, 100), (255, 200, 100), (255, 220, 100), (255, 240, 100), (240, 255, 100), (220, 255, 100), (200, 255, 100), (180, 255, 100), (160, 255, 100), (140, 255, 100), (120, 255, 100), (100, 255, 100), (100, 255, 120), (100, 255, 140), (100, 255, 160), (100, 255, 180), (100, 255, 200), (100, 255, 220), (100, 255, 240), (100, 240, 255), (100, 220, 255), (100, 200, 255), (100, 180, 255), (100, 160, 255), (100, 140, 255), (100, 120, 255), (100, 100, 255), (120, 100, 255), (140, 100, 255), (160, 100, 255), (180, 100, 255), (200, 100, 255), (220, 100, 255), (240, 100, 255), (255, 100, 255), (255, 100, 230), (255, 100, 210), (255, 100, 190), (255, 100, 170), (255, 100, 150), (255, 100, 130), (255, 100, 110)]
        if self.bow < len(rain)-1:
            self.bow += 1
        else:
            self.bow = 0
        self.color = rain[self.bow]
        
    def Rect(self):
        return self.ball
      

class Block:
    def __init__(self, x, y, width, height, color):
        self.x, self.y = x, y
        self.width = width
        self.height = height
        self.color = color
        self.damage = 100
  
        if color == white:
            self.health = 100
        elif color == red:
            self.health = 150
        elif color == pink:
            self.health = 50
        elif color == green:
            self.health = 10
        elif color == gold:
            self.health = 420
        elif color == blue:
            self.health = 30
  
        self.blockRect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.block = pygame.draw.rect(screen, self.color, self.blockRect)
  
    def display(self):
        if self.health > 0:
            self.brick = pygame.draw.rect(screen, self.color, self.blockRect)
  
    def hit(self):
        self.health -= self.damage
  
    def Rect(self):
        return self.blockRect
  
    def Health(self):
        return self.health
    
    def info(self):
        info = [self.x, self.y, self.width, self.height]
        return info


class Platform:
    def __init__(self, x, y, width, height, speed, color):
        self.x, self.y = x, y
        self.width = width
        self.height = height
        self.color = color
        self.speed = speed 
        self.bow = 0
        self.bow = 0

        self.platformRect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.platform = pygame.draw.rect(screen, self.color, self.platformRect)
  
    def display(self):
        self.platform = pygame.draw.rect(screen, self.color, self.platformRect)

    def move(self, Δx):
        self.x += self.speed*Δx
        if self.x+self.width >= width:
            self.x = width-self.width
        elif self.x <= 0:
            self.x = 0

        rain = [(255, 100, 100), (255, 110, 100), (255, 120, 100), (255, 130, 100), (255, 140, 100), (255, 150, 100), (255, 160, 100), (255, 170, 100), (255, 180, 100), (255, 190, 100), (255, 200, 100), (255, 210, 100), (255, 220, 100), (255, 230, 100), (255, 240, 100), (255, 250, 100), (255, 255, 100), (240, 255, 100), (230, 255, 100), (220, 255, 100), (210, 255, 100), (200, 255, 100), (190, 255, 100), (180, 255, 100), (170, 255, 100), (160, 255, 100), (150, 255, 100), (140, 255, 100), (130, 255, 100), (120, 255, 100), (110, 255, 100), (100, 255, 100), (100, 255, 110), (100, 255, 120), (100, 255, 130), (100, 255, 140), (100, 255, 150), (100, 255, 160), (100, 255, 170), (100, 255, 180), (100, 255, 190), (100, 255, 200), (100, 255, 210), (100, 255, 220), (100, 255, 230), (100, 255, 240), (100, 255, 250), (100, 255, 255), (100, 240, 255), (100, 230, 255), (100, 220, 255), (100, 210, 255), (100, 200, 255), (100, 190, 255), (100, 180, 255), (100, 170, 255), (100, 160, 255), (100, 150, 255), (100, 140, 255), (100, 130, 255), (100, 120, 255), (100, 110, 255), (100, 100, 255), (110, 100, 255), (120, 100, 255), (130, 100, 255), (140, 100, 255), (150, 100, 255), (160, 100, 255), (170, 100, 255), (180, 100, 255), (190, 100, 255), (200, 100, 255), (210, 100, 255), (220, 100, 255), (230, 100, 255), (240, 100, 255), (255, 100, 255), (255, 100, 240), (255, 100, 230), (255, 100, 220), (255, 100, 210), (255, 100, 200), (255, 100, 190), (255, 100, 180), (255, 100, 170), (255, 100, 160), (255, 100, 150), (255, 100, 140), (255, 100, 130), (255, 100, 120), (255, 100, 110), (255, 100, 100)]

        if 0 <= self.bow < 5*len(rain)-1 :
            self.bow += 1
        else:
            self.bow = 0
        
        self.color = rain[self.bow//5]
  
        self.platformRect = pygame.Rect(self.x, self.y, self.width, self.height)

    def reset(self):
        self.Δx = 10

    def stop(self):        
        self.bow = -1
        self.Δx = 0
        self.x ,self.y = 0, height-50

    def Rect(self):
        return self.platformRect
  
  
def check_collision(rect, ball):
    if pygame.Rect.colliderect(rect, ball):
        return True
  
    return False
  

def heart_of_blocks(blockwidth, blockheight, horizontalGap, verticalGap, level):
    listOfBlocks = []
  
    for i in range(0, width, blockwidth+horizontalGap):
        for j in range(50, height*5//9, blockheight+verticalGap):
            listOfBlocks.append(Block(i, j, blockwidth, blockheight, random.choice([white, red])))
    
    if level == 1:
        indices_to_remove = [49, 48, 47, 43, 42, 41, 35, 22, 21, 14, 13, 7, 6, 5, 1]
        for i in indices_to_remove:
            listOfBlocks.pop(i-1)
    
    elif level == 2:
        indices_to_remove = [45, 44, 43, 41, 40, 37, 36, 34, 29, 27, 26, 15, 13, 12, 9, 8, 3, 2, 1]
        for i in indices_to_remove:
            listOfBlocks.pop(i-1)

    elif level == 3:
        indices_to_remove = [49, 48, 47, 45, 44, 43, 42, 41, 39, 37, 36, 35, 33, 31, 29, 27, 25, 23, 21, 19, 17, 15, 14, 13, 11, 9, 8, 7, 6, 5, 3, 2, 1]
        dodatkowy_blok_leczący = Block(180, 155, blockwidth, blockheight, green)
        for i in indices_to_remove:
            listOfBlocks.pop(i-1)
        listOfBlocks.append(dodatkowy_blok_leczący)

    elif level == 4:
        indices_to_remove = [42, 41, 39, 38, 37, 34, 33, 32, 30, 23, 20, 19, 18, 16, 13, 11, 10, 9]
        for i in indices_to_remove:
            listOfBlocks.pop(i-1)

    elif level == 5:
        indices_to_remove = [42, 41, 40, 38, 37, 36, 28, 27, 26, 25, 24, 23, 22, 21, 15, 12, 11, 10]
        for i in indices_to_remove:
            listOfBlocks.pop(i-1)
    
    elif level == 6:
        indices_to_remove = [41, 40, 39, 38, 37, 34, 30, 27, 25, 23, 20, 16, 13, 12, 11, 10, 9]
        dodatkowy_blok_jackpot = Block(180, 155, blockwidth, blockheight, gold)
        for i in indices_to_remove:
            listOfBlocks.pop(i-1)
        listOfBlocks.append(dodatkowy_blok_jackpot)

    elif level == 7:
        indices_to_remove = [49, 42, 41, 40, 39, 38, 37, 30, 27, 26, 25, 23, 20, 16, 13, 12, 11, 10, 9]
        dodatkowy_blok_speed_boost_1 = Block(120, 190, blockwidth, blockheight, blue)
        dodatkowy_blok_speed_boost_2 = Block(360, 260, blockwidth, blockheight, blue)
        for i in indices_to_remove:
            listOfBlocks.pop(i-1)  
        listOfBlocks.append(dodatkowy_blok_speed_boost_1)     
        listOfBlocks.append(dodatkowy_blok_speed_boost_2)  

    elif level == 8:
        indices_to_remove = [49, 47, 45, 43, 41, 39, 37, 35, 33, 31, 29, 27, 25, 23, 21, 19, 17, 15, 13, 11, 9, 7, 5, 3, 1]
        for i in indices_to_remove:
            listOfBlocks.pop(i-1) 

    elif level == 9:
        indices_to_remove = [47, 46, 45, 41, 40, 38, 37, 35, 34, 30, 29, 28, 25, 22, 21, 20, 16, 15, 13, 12, 10, 9, 5, 4, 3]
        dodatkowy_blok_leczący = Block(180, 155, blockwidth, blockheight, green)
        for i in indices_to_remove:
            listOfBlocks.pop(i-1)  
        listOfBlocks.append(dodatkowy_blok_leczący)

    elif level == 10:
        indices_to_remove = [47, 43, 37, 36, 35, 31, 30, 29, 23, 22, 21, 17, 16, 15, 9, 8, 5, 1]
        dodatkowy_blok_speed_boost_1 = Block(120, 50, blockwidth, blockheight, blue)
        dodatkowy_blok_speed_boost_2 = Block(240, 50, blockwidth, blockheight, blue)
        dodatkowy_blok_jackpot = Block(180, 85, blockwidth, blockheight, gold)
        for i in indices_to_remove:
            listOfBlocks.pop(i-1) 
        listOfBlocks.append(dodatkowy_blok_speed_boost_1)     
        listOfBlocks.append(dodatkowy_blok_speed_boost_2) 
        listOfBlocks.append(dodatkowy_blok_jackpot) 


    return listOfBlocks
  

# def gameOver():    
    # gameOver = True
    # gameOver_text = game_title_font.render("Podaj swoją nazwę, aby zapisać wynik.\nZatwierdź go wsiskając spację", True, white)
    # gameOver_nick = game_title_text.get_rect(midtop=(width / 2, 60))
    # while gameOver:
    #     screen.fill(black)
    #     screen.blit(gameOver_text, gameOver_nick)
    #     for event in pygame.event.get():
    #         if event.type == pygame.QUIT:
    #             return False
                            
    #         if event.type == pygame.KEYDOWN:
    #             if event.key == pygame.K_SPACE:
    #                 menu_state = "menu"


def ranking(lista):
    scores = []
    sorted_scores = []
    top_scores = []
    for i in range(len(lista)):
        scores.append((lista[i][1], lista[i][0]))  # Dodanie pary (wynik, imię) do listy
    scores.sort(reverse=True)  # Sortowanie w odwróconej kolejności
    for score in scores:
        sorted_scores.append(f"Imię: {score[1]}, Wynik: {score[0]}")
    for i in range(5):
        top_scores.append(sorted_scores[i])
    return top_scores

def save_ranking(list):
    with open('scores.txt', 'w') as file:
        file.write(str(list))
# Przyciski
game_title_font = pygame.font.SysFont("OCR A Extended", 25)
game_title_text = game_title_font.render("Zniszcz Bloczki :)", True, white)
game_title = game_title_text.get_rect(midtop=(width / 2, 60))

button_margines = 10  # Dodatkowy margines wokół przycisku
button_bg = button_color  # Kolor tła przycisku
button_frame = button_color_2  # Kolor obramowania przycisku
button_1_font = pygame.font.SysFont("OCR A Extended", 20)
emoji_font = pygame.font.SysFont("segoeuiemoji", 20)

button_close_text = button_1_font.render("Zamknij", True, white)
button_close = button_close_text.get_rect(bottomright=(width - 30, height - 30))

button_autor_text = button_1_font.render("O Autorze", True, white)
button_autor = button_autor_text.get_rect(bottomleft=(30, height - 30))

button_ranking_text = button_1_font.render("Ranking", True, white)
button_ranking = button_ranking_text.get_rect(bottomright=(width - 30, 2 * height // 5))

button_zasady_text = button_1_font.render("Zasady", True, white)
button_zasady = button_zasady_text.get_rect(bottomleft=(30, 2 * height // 5))

button_2_font = pygame.font.SysFont("OCR A Extended", 25)
button_start_text = button_2_font.render("START", True, white)
button_start = button_start_text.get_rect(midbottom=(width // 2, 3.3 * height // 5))

button_powrot_text = button_1_font.render("Powrót", True, white)
button_powrot = button_powrot_text.get_rect(midbottom=(width // 2, height - 30))

button_zatwierdz_text = button_1_font.render("Zatwierdz", True, white)
button_zatwierdz = button_zatwierdz_text.get_rect(midbottom=(width // 2, height - 30))


button_muzyka_text = emoji_font.render("\U0001F3B6" , True, white)
button_muzyka = button_muzyka_text.get_rect(midbottom=(width // 2, 2 * height // 5))

def main():
    FPS = 50
    Muzyka=False
    menu_state = "menu"
    running = True
    nick_rect = pygame.Rect(100, 100, 200, 30)
    nick = ""
    is_typing = False
    lives = 3
    score = 0
    level = 1
    levels = 1
  
    scoreText = game_font.render("score", True, white)
    scoreTextRect = scoreText.get_rect()
    scoreTextRect.center = (40, height-10)
  
    livesText = game_font.render("Lives", True, white)
    livesTextRect = livesText.get_rect()
    livesTextRect.center = (170, height-10)

    levelsText = game_font.render("Level", True, white)
    levelsTextRect = levelsText.get_rect()
    levelsTextRect.center = (300, height-10)
  
    platform = Platform(0, height-50, 100, 10, 10, white)
    platform_Δx = 0
  
    ball = Ball(0, height-150, 7, 5, white)
  
    blockwidth, blockheight = 40, 15
    horizontalGap, verticalGap = 20, 20
  
    listOfBlocks = heart_of_blocks(blockwidth, blockheight, horizontalGap, verticalGap, level)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Kliknięcie lewym przyciskiem myszy
                    if menu_state == "menu":
                        if button_close.collidepoint(event.pos):
                            running = False
                        elif button_autor.collidepoint(event.pos):
                            menu_state = "autor"  # Zmiana stanu na "autor"
                        elif button_ranking.collidepoint(event.pos):
                            menu_state = "ranking"  # Zmiana stanu na "autor"
                        elif button_zasady.collidepoint(event.pos):
                            menu_state = "zasady"  # Zmiana stanu na "autor"
                        elif button_start.collidepoint(event.pos):
                            menu_state = "start"  # Zmiana stanu na "autor"
                        elif button_muzyka.collidepoint(event.pos):
                            if Muzyka:
                                Muzyka=False
                                pygame.mixer.music.stop()
                            else:
                                Muzyka=True
                                pygame.mixer.music.play(loops=-1)
                       

                    else:
                        if nick_rect.collidepoint(event.pos):
                            is_typing = True
                            button_active = True
                        else:
                            is_typing = False
                            button_active = False
                        if button_powrot.collidepoint(event.pos) or button_zatwierdz.collidepoint(event.pos):
                            menu_state = "menu"  # Zmiana stanu na "menu"
                            if nick == '':
                                nick = 'Nie znane'
                            listOfScores.append([nick, score])
                            save_ranking(listOfScores)
                            FPS = 50
                            lives = 3
                            score = 0
                            level = 1
                            levels = 1
                            platform.bow = 0
                            ball.reset()
                            platform.reset()
                            listOfBlocks = heart_of_blocks(blockwidth, blockheight, horizontalGap, verticalGap, level)
    
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    platform_Δx = -1
                if event.key == pygame.K_RIGHT:
                    platform_Δx = 1
                if is_typing:
                    if event.key == pygame.K_BACKSPACE:
                        nick = nick[:-1]
                    else:
                        if len(nick)<=15:
                          nick += event.unicode
                    
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    platform_Δx = 0


        screen.blit(background, (0, 0))

        if menu_state == "menu":
            pygame.draw.rect(screen, button_bg, button_close.inflate(button_margines * 2, button_margines * 2))
            pygame.draw.rect(screen, button_frame, button_close.inflate(button_margines * 2, button_margines * 2), 2)
            screen.blit(button_close_text, button_close.topleft)

            pygame.draw.rect(screen, button_bg, button_autor.inflate(button_margines * 2, button_margines * 2))
            pygame.draw.rect(screen, button_frame, button_autor.inflate(button_margines * 2, button_margines * 2), 2)
            screen.blit(button_autor_text, button_autor.topleft)

            pygame.draw.rect(screen, button_bg, button_ranking.inflate(button_margines * 2, button_margines * 2))
            pygame.draw.rect(screen, button_frame, button_ranking.inflate(button_margines * 2, button_margines * 2), 2)
            screen.blit(button_ranking_text, button_ranking.topleft)

            pygame.draw.rect(screen, button_bg, button_zasady.inflate(button_margines * 2, button_margines * 2))
            pygame.draw.rect(screen, button_frame, button_zasady.inflate(button_margines * 2, button_margines * 2), 2)
            screen.blit(button_zasady_text, button_zasady.topleft)

            pygame.draw.rect(screen, button_bg, button_start.inflate(button_margines * 2, button_margines * 2))
            pygame.draw.rect(screen, button_frame, button_start.inflate(button_margines * 2, button_margines * 2), 2)
            screen.blit(button_start_text, button_start.topleft)

            pygame.draw.rect(screen, button_bg, button_muzyka.inflate(button_margines * 2, button_margines * 2))
            pygame.draw.rect(screen, button_frame, button_muzyka.inflate(button_margines * 2, button_margines * 2), 2)
            screen.blit(button_muzyka_text, button_muzyka.topleft)

            screen.blit(game_title_text, game_title)

        elif menu_state == "autor":
            screen.fill(black)
            author_font = pygame.font.SysFont("Consolas", 15)
            author_text = author_font.render("Autorem gry jest pierwszoroczny \nstudent Politechniki Wrocławskiej \nz kierunku Matematyki Stosowanej \nDominik Hołoś. Stworzył ją w ramach \nściśle tajnego projektu noszącego \nnazwę 'lista 6'. Dominik programuje \nod niespełna roku, ale świetnie \nsobie z tym radzi. Jest wytrwały \ni pracowity. Pasjonują go nauki \nścisłe, uwielbia matematykę i biologię. \nPosiada własną kolekcję roślin, \nktóre są jego oczkiem w głowie.", True, white)
            author_rect = author_text.get_rect(center=(width // 2, height // 3))
            screen.blit(author_text, author_rect)

            pygame.draw.rect(screen, button_bg, button_powrot.inflate(button_margines * 2, button_margines * 2))
            pygame.draw.rect(screen, button_frame, button_powrot.inflate(button_margines * 2, button_margines * 2), 2)
            screen.blit(button_powrot_text, button_powrot.topleft)

        elif menu_state == "ranking":
            screen.fill(black)
            author_font = pygame.font.SysFont("Consolas", 15)
            author_text = author_font.render("1 Miejsce: " + ranking(listOfScores)[0] + "\n2 Miejsce: " + ranking(listOfScores)[1] + "\n3 Miejsce: " + ranking(listOfScores)[2] + "\n4 Miejsce: " + ranking(listOfScores)[3] + "\n5 Miejsce: " + ranking(listOfScores)[4], True, white)
            author_rect = author_text.get_rect(center=(width // 2, height // 3))
            screen.blit(author_text, author_rect)

            pygame.draw.rect(screen, button_bg, button_powrot.inflate(button_margines * 2, button_margines * 2))
            pygame.draw.rect(screen, button_frame, button_powrot.inflate(button_margines * 2, button_margines * 2), 2)
            screen.blit(button_powrot_text, button_powrot.topleft)

        elif menu_state == "zasady":
            screen.fill(black)
            author_font = pygame.font.SysFont("Consolas", 15)
            author_text = author_font.render("Twoją misją jest rozbicie wszystkich \ncegiełek zlokalizowanych u góry ekranu. \nUżywamy do tego niewielkiej kulki, którą \nodbijamy przy pomocy platformy u dołu. \nGracz ma wpływ tylko na ustawienie \nplatformy (może ją na bieżąco przesuwać \nw lewo lub w prawo, poprzez naciskanie \nodpowiednich strzałek na klawiaturze \nstarając się odbić kulkę). Za każdą \nrozbitą cegiełkę uzyskujesz punkty, \n masz trzy życia które tracisz, \ngdy kulka dotknie dolnej krawędzi ekranu.\nWyróżniamy trzy rodzaje bloczków: \n-biały (wymagane 1 uderzenie)\n-czerwony (wymagane 2 uderzenia)\n (po pierwszym zbiciu zmienia kolor na róż)\n-zielony (wymagane 1 uderzenie)\n(daje szansę na zdobycie dodatkowego życia)", True, white)
            author_rect = author_text.get_rect(center=(width // 2, 2*height // 5))
            screen.blit(author_text, author_rect)

            pygame.draw.rect(screen, button_bg, button_powrot.inflate(button_margines * 2, button_margines * 2))
            pygame.draw.rect(screen, button_frame, button_powrot.inflate(button_margines * 2, button_margines * 2), 2)
            screen.blit(button_powrot_text, button_powrot.topleft)

        elif menu_state == "start":
            #screen.blit(background_2, (0, 0))
            screen.fill(black)
            screen.blit(scoreText, scoreTextRect)
            screen.blit(livesText, livesTextRect)
            screen.blit(levelsText, levelsTextRect)
    
            scoreText = game_font.render("Score : " + str(score), True, white)
            livesText = game_font.render("Lives : " + str(lives), True, white)
            levelsText = game_font.render("Level : " + str(levels), True, white)
    
            if not listOfBlocks:
                ball.reset()
                level += 1
                levels +=1
                FPS += 2
                if level == 11:
                    level=1
                listOfBlocks = heart_of_blocks(blockwidth, blockheight, horizontalGap, verticalGap, level)
    
            if lives <= 0:
                ball.stop()
                platform.stop()
                listOfBlocks = []
                screen.fill(black)
                gameOver_text = game_font.render("Jak zapisać twój wynik?", True, white)
                gameOver_nick = game_title_text.get_rect(midtop=(width / 2, 60))
                screen.blit(gameOver_text, gameOver_nick)

                gameOver_score_text = button_1_font.render("Twój wynik to: " + str(score), True, white)
                gameOver_score = gameOver_score_text.get_rect(midbottom=(width // 2, height//3))
                screen.blit(gameOver_score_text, gameOver_score.topleft)


                pygame.draw.rect(screen, white, nick_rect, 2)
                nick_surface = game_font.render(nick, True, white)
                screen.blit(nick_surface, (nick_rect.x + 5, nick_rect.y + 5))
                

                pygame.draw.rect(screen, button_bg, button_zatwierdz.inflate(button_margines * 2, button_margines * 2))
                pygame.draw.rect(screen, button_frame, button_zatwierdz.inflate(button_margines * 2, button_margines * 2), 2)
                screen.blit(button_zatwierdz_text, button_zatwierdz.topleft)
                    
                # for event in pygame.event.get():
                #     if event.type == pygame.QUIT:
                #         return False
                
    
            if(check_collision(platform.Rect(),ball.Rect())):
                ball.hit()
            for block in listOfBlocks:
                if(check_collision(block.Rect(), ball.Rect())):
                    ball.hit()
                    block.hit()
                    if Muzyka:
                        collision_sound.play()
                    else:
                        collision_sound.stop()
    
                    if -50<= block.Health() <= 0:
                        listOfBlocks.pop(listOfBlocks.index(block))
                        score += 5
                    elif block.Health() == -90:
                        listOfBlocks.pop(listOfBlocks.index(block))
                        score += 5
                        probability=random.random()
                        if probability <=0.5:
                            lives += 1
                            print("uzyskujesz nowe życia") 
                        elif 0.5 < probability <=0.95:
                            print("nie uzyskujesz nowego życia") 
                        else:
                            lives += 2
                            print("uzyskujesz 2 nowe życia") 
                    elif block.Health() == -80:
                        listOfBlocks.pop(listOfBlocks.index(block))
                        score += 500
                    elif block.Health() == -70:                   
                        FPS += 4
                        listOfBlocks.pop(listOfBlocks.index(block))
                        score += 5

                    elif block.Health() == 50:
                        info=block.info()
                        listOfBlocks[listOfBlocks.index(block)]=Block(info[0], info[1], info[2], info[3], pink)
    
            platform.move(platform_Δx)
            lifeLost = ball.move()
    
            if lifeLost:
                lives -= 1
                ball.reset()
                print(lives)

            platform.display()
            ball.display()
    
            for block in listOfBlocks:
                block.display()
    
            pygame.display.update()
            clock.tick(FPS)

        pygame.display.flip()

if __name__ == "__main__":
    main()
    pygame.quit()
    sys.exit()
    pygame.mixer.music.stop()
    pygame.mixer.quit()